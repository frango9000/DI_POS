from app.data import VendidosDao

print(VendidosDao.get_total(35))
