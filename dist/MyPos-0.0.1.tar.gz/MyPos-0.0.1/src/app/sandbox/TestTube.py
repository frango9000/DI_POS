from src.app.data import VendidosDao

print(VendidosDao.get_total(35))
