docs package
============

Submodules
----------

docs\.conf module
-----------------

.. automodule:: docs.conf
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: docs
    :members:
    :undoc-members:
    :show-inheritance:
