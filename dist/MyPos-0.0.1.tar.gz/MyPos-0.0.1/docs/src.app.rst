src\.app package
================

Subpackages
-----------

.. toctree::

    src.app.data
    src.app.model
    src.app.reportes
    src.app.sandbox
    src.app.view

Submodules
----------

src\.app\.Globals module
------------------------

.. automodule:: src.app.Globals
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: src.app
    :members:
    :undoc-members:
    :show-inheritance:
