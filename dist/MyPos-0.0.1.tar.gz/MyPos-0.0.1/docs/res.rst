res package
===========

Module contents
---------------

.. automodule:: res
    :members:
    :undoc-members:
    :show-inheritance:
