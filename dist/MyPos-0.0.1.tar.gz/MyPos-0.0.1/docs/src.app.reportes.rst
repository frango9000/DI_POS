src\.app\.reportes package
==========================

Submodules
----------

src\.app\.reportes\.MassReportGenerator module
----------------------------------------------

.. automodule:: src.app.reportes.MassReportGenerator
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.reportes\.Reportes module
-----------------------------------

.. automodule:: src.app.reportes.Reportes
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: src.app.reportes
    :members:
    :undoc-members:
    :show-inheritance:
