src\.app\.model package
=======================

Submodules
----------

src\.app\.model\.Cliente module
-------------------------------

.. automodule:: src.app.model.Cliente
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.model\.Producto module
--------------------------------

.. automodule:: src.app.model.Producto
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.model\.Vendido module
-------------------------------

.. automodule:: src.app.model.Vendido
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.model\.Venta module
-----------------------------

.. automodule:: src.app.model.Venta
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: src.app.model
    :members:
    :undoc-members:
    :show-inheritance:
