src\.app\.data package
======================

Submodules
----------

src\.app\.data\.ClientesDao module
----------------------------------

.. automodule:: src.app.data.ClientesDao
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.data\.GenericDao module
---------------------------------

.. automodule:: src.app.data.GenericDao
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.data\.ProductosDao module
-----------------------------------

.. automodule:: src.app.data.ProductosDao
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.data\.VendidosDao module
----------------------------------

.. automodule:: src.app.data.VendidosDao
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.data\.VentasDao module
--------------------------------

.. automodule:: src.app.data.VentasDao
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: src.app.data
    :members:
    :undoc-members:
    :show-inheritance:
