src package
===========

Subpackages
-----------

.. toctree::

    src.app

Submodules
----------

src\.App module
---------------

.. automodule:: src.App
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: src
    :members:
    :undoc-members:
    :show-inheritance:
