src\.app\.view package
======================

Submodules
----------

src\.app\.view\.CajaUI module
-----------------------------

.. automodule:: src.app.view.CajaUI
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.ClienteEditor module
------------------------------------

.. automodule:: src.app.view.ClienteEditor
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.ClientesUI module
---------------------------------

.. automodule:: src.app.view.ClientesUI
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.MainUI module
-----------------------------

.. automodule:: src.app.view.MainUI
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.ProductoEditor module
-------------------------------------

.. automodule:: src.app.view.ProductoEditor
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.ProductosUI module
----------------------------------

.. automodule:: src.app.view.ProductosUI
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.PyDialogs module
--------------------------------

.. automodule:: src.app.view.PyDialogs
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.ReportesUI module
---------------------------------

.. automodule:: src.app.view.ReportesUI
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.VendidoEditor module
------------------------------------

.. automodule:: src.app.view.VendidoEditor
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.VendidosUI module
---------------------------------

.. automodule:: src.app.view.VendidosUI
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.VentaEditor module
----------------------------------

.. automodule:: src.app.view.VentaEditor
    :members:
    :undoc-members:
    :show-inheritance:

src\.app\.view\.VentasUI module
-------------------------------

.. automodule:: src.app.view.VentasUI
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: src.app.view
    :members:
    :undoc-members:
    :show-inheritance:
